from django.shortcuts import render

# Create your views here.
def home(request):
    return render(request, "app1/home.html")


#calculadora de imc
def himc(request):
    return render(request, "app1/home_imc.html")

def imc(request):
    peso = float(request.GET.get('peso'))
    altura = float(request.GET.get('altura'))

    imc = peso / (altura ** 2)
    imc = round(imc, 2)

    if imc < 18.5:
        categoria = 'Abaixo do Peso'
        print(categoria)

    elif 18.5 <= imc < 24.9:
        categoria = 'Peso Normal'
        print(categoria)

    elif 25 <= imc < 29.9:
        categoria = 'Sobrepeso'
        print(categoria)

    elif 30 <= imc < 34.9:
        categoria = 'Obesidade Grau I'

    elif 35 <= imc < 39.9:
        categoria = 'Obesidade Grau II'

    else:
        categoria = "Obesidade Grau III"
    return render(request, 'app1/imc.html', {'imc': imc, 'categoria': categoria})



#calculadora de diferença
def hdiferenca(request):
    return render(request, "app1/home_diferenca.html")

def diferenca(request):
    A = int(request.GET.get('valor_a'))
    B = int(request.GET.get('valor_b'))

    if A < B:
        diferenca = B - A
        print(diferenca)
    elif B < A:
        diferenca = A - B
        print(diferenca)
    else:
        diferenca = 'os numeros são iguais'
        print(diferenca)
    return render(request, "app1/diferenca.html", {'diferenca': diferenca})


#calculadora
def hcalculadora(request):
    return render(request, "app1/home_calculadora.html")

def calculadora(request):
    from_scale = request.GET.get("from_scale")
    to_scale = request.GET.get("to_scale")
    valor = request.GET.get("valor")

    celsius = "Nenhum Valor"
    fahrenheit = "Nenhum Valor"
    kelvin = "Nenhum Valor"

    if from_scale == "celsius" and to_scale == "fahrenheit":
        celsius = float(valor)
        fahrenheit = (9 * celsius + 160) / 5
        fahrenheit = round(fahrenheit, 2)
    elif from_scale == "celsius" and to_scale == "kelvin":
        celsius = float(valor)
        kelvin = celsius + 273.15
        kelvin = round(kelvin, 2)
    elif from_scale == "fahrenheit" and to_scale == "celsius":
        fahrenheit = float(valor)
        celsius = (5 * (fahrenheit - 32)) / 9
        celsius = round(celsius, 2)
    elif from_scale == "fahrenheit" and to_scale == "kelvin":
        fahrenheit = float(valor)
        c = (5 * (fahrenheit - 32)) / 9
        kelvin = c + 273.15
        kelvin = round(kelvin, 2)
    elif from_scale == "kelvin" and to_scale == "celsius":
        kelvin = float(valor)
        celsius = kelvin - 273.15
        celsius = round(celsius, 2)
    elif from_scale == "kelvin" and to_scale == "fahrenheit":
        kelvin = float(valor)
        c = kelvin - 273.15
        fahrenheit = (c * 9 / 5) + 32
        fahrenheit = round(fahrenheit, 2)

    return render(request, 'app1/calculadora.html', {'celsius': celsius, 'fahrenheit': fahrenheit, 'kelvin': kelvin})



#bascara
def hbascara(request):
    return render(request, "app1/home_bascara.html")

def bascara(request):
    a = float(request.GET.get('a'))
    b = float(request.GET.get('b'))
    c = float(request.GET.get('c'))

    delta = ( (b ** 2) - 4 * a * c)

    if a == 0:
        x1 = ('o valor de a deve ser diferente de zero')
        x2 = ('o valor de a deve ser diferente de zero')
    elif delta < 0:
        x1 = (" 'não há raiz real' ")
        x2 = (" 'não há raiz real' ")
    else:
        x1 = (-b + delta ** (1 / 2)) / (2 * a)
        x2 = (-b - delta ** (1 / 2)) / (2 * a)

    return render(request, "app1/bascara.html", {'x1' : x1, 'x2' : x2})